from pinject_design.di.injected import Injected, injected_function
from pinject_design.di.util import Design,EmptyDesign
from pinject_design.di.designed import Designed

