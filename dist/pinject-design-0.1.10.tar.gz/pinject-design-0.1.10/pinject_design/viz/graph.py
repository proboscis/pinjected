from pyvis.network import Network

from pinject_design.di.util import Design

