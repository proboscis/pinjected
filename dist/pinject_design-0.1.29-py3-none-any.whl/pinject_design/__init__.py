from pinject_design.di.injected import Injected, injected_factory
from pinject_design.di.util import Design

